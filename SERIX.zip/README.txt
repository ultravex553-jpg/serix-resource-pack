CratesPack Merged

Crates (custom_model_data 1..5 = common, rare, epic, legendary, mythic):
  light_gray / blue / purple / orange / red shulker box -> 3D crate
  amethyst_shard -> 3D crystal cluster
  netherite_sword -> short sword
Works on every version through custom_model_data (set it in your crates plugin config, e.g. custom-model-data: 3 for epic).
Command example (1.21.4+): /give @p purple_shulker_box[custom_model_data={floats:[3f]}]
1.21.4+ also: item_model="crates:crate_epic" | "crates:crystal_epic" | "crates:shortsword_epic"
Other shulker colors use the Mystical Shulkers textures.

Spears for players on older versions (no 1.21.11 spear item):
  The old client cannot show the new item, so the server must give them a carrier item instead:
  <material>_sword with custom_model_data 100 -> 3D spear (wooden, stone, copper, iron, golden, diamond, netherite).
  1.21.4+ also: item_model="crates:spear_<material>"

SERIX armor (iron, gold, diamond, netherite):
  Full set spells SERIX in orange: helmet = S, chestplate = E R, leggings = I, boots = X.
  New inventory icons with orange trim. Works on all versions (old armor paths + 1.21.2+ equipment paths).

3D shulker boxes: every shulker box item (all 16 colors + undyed) now shows as a 3D crate in inventory, hand and on the ground.
The 5 crate colors keep their tier models through custom_model_data 1..5.
Placed shulker blocks are drawn by the game as entities, so only their texture changes (Mystical Shulkers / crate textures).
SERIX armor: letters now run lengthwise (rotated 90 degrees) with an outline.

Animations: crates (pulsing gem + light sweep), crystals (shimmer + twinkles), short swords & spears (blade sheen, gem pulse),
SERIX armor icons (traveling orange glow). Textures drawn as entities (placed shulkers, worn armor) cannot be animated by resource packs.


=== SERIX ESC menu & scoreboard glyphs ===
SERIX resource pack - glyphs
U+E000 + E020-E033 + E100-E103: ESC menu composition (logo, divider, "Leave us?" box) - automatic via menu.game
U+E001 logo 16px (scoreboard title)
U+E002 logo 9px (inline)
U+E010 coin | E011 sword | E012 skull | E013 crown | E014 heart | E015 star

Merge note: the SERIX orange buttons (widget/button*.png) override the CratesPack ones.


=== Update ===
SERIX armor removed (worn armor + inventory icons are vanilla again). Fire recolored to gold (&6).
Amethyst shard is now the 3D crystal by default. Fullbright (night vision look) via core/lightmap.fsh (1.21.2+).
Pack description: SERIX Based-on Pack.
